git add .
git commit -m "message"
git push
